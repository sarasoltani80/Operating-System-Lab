#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <signal.h>

#define MAXCHILD 5
#define ARRAYSIZE 100
int flag = 0;
int * array;

void handler1(int signo)
{
	//printf("sara4");
	switch(signo)
	{
		//printf("sara3");
		case SIGUSR1:
		//printf("sara1");
		flag = 1;
		break;
	}
}
void task(int i, int *data)
{
	struct sigaction action1;
	action1.sa_handler = handler1;
	action1.sa_flags = 0;
	sigaction(SIGUSR1,(struct sigaction *) &action1,NULL);
	
	while(1) {
		pause();
		if(flag)
		{
			printf("sara");
			//int start= (i)*20;
			for(int j = i; j<100; j+=MAXCHILD)
				array[j]= data[j] *2 + 1;
			break;
		}
	}
	exit(0);
}




int main()
{
	pid_t child [MAXCHILD];
	int size = ARRAYSIZE * sizeof(int);
	void *data = mmap(0, size,PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);
	array = (int *) data;
	if(data == (void *)-1){
        perror("mmap()");
        return EXIT_FAILURE;
    }
    
    for(int i=0; i< MAXCHILD; i++)
    {
	child[i] = fork();
	if(child[i] == 0)
	{
		task(i, data);
	}
    }
    usleep(10000);
    
    for(int i=0 ; i<ARRAYSIZE; i++)
    {
    	array[i] = i;
    }
    
    for(int i=0; i< MAXCHILD; i++)
    {
    	//printf("sara2");
    	kill(child[i],SIGUSR1);	
    }
    
    while(wait(NULL)>0);
    //if(wait(NULL)>0)
    //{
    	for(int c = 0 ; c< ARRAYSIZE; c++)
    		printf("\nindex: %d   element: %d\t", c , array[c]);
    //}
    
    return 0;
    
}
    
    
    
    
    

