#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "protocol.h"



int main()
{
    int fd = shm_open(NAME, O_CREAT | O_TRUNC | O_RDWR, 0777);
    if (fd<0) {
        perror("shm_open()");
        return EXIT_FAILURE;
    }
    
    int size = 2 * sizeof(struct data);

    ftruncate(fd, size);

    struct data *d = (struct data*)mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if(d == (struct data *)-1){
        perror("mmap()");
        return EXIT_FAILURE;
    }

    /*int *array = (int *)data;
    char *msg = (char *)(data + ARRAY_S); // get address of messge*/

    
    printf("sender address: %p\n", d);

    // write array in shared memory
    for (int i = 0; i < NUM; i++) {
    	int r = rand() % 5 + 1;
        d[0].array[i] = r;
        int r1 = rand() % 5 + 1;
        d[1].array[i] = r1;
    }

    // write messge in shared memory
    strncat(d[0].msg, "Sara", STR_L);
    strncat(d[1].msg, "Sahar", STR_L);
    
    munmap(d, size);

    close(fd);
    return EXIT_SUCCESS;
}
