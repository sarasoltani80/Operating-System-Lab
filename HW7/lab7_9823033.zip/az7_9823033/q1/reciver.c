#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

int main()
{
    int fd = shm_open(NAME, O_RDONLY, 0666);
    if (fd<0) {
        perror("shm_open()");
        return EXIT_FAILURE;
    }

    int size = 2 * sizeof(struct data);

    struct data *data = (struct data*)mmap(0, size, PROT_READ, MAP_SHARED, fd, 0); //struct that has defined pointed to the first of the address of the space that mmap stored
    if(data == (void *)-1){
        perror("mmap()");
        return EXIT_FAILURE;
    }
    

    /*int *array = (int *)data;
    char *msg = (char *)(data + ARRAY_S);*/
    
    printf("reciver address: %p\n", data);

    for (int i = 0; i < NUM; i++) {
        printf("i:%d***struct1:%d***struct2:%d \n",i,data[0].array[i],data[1].array[i]);
    }

    printf("msg of struct1: %s***msg of struct2: %s\n", data[0].msg, data[1].msg);

    munmap(data, size);

    close(fd);

    // delete file
    shm_unlink(NAME);
    return EXIT_SUCCESS;
}
