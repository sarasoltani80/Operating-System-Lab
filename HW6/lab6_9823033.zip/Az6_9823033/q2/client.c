#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

#define FIFO_PATH "q2.pipe"

struct data{
 int a;
 int b;
 char n;

};

int main()
{

	int a,b;
	long int c;
	char n;
	int fd;
 while(1)
 {
	 struct data data1;
	 scanf("%c%d%d",&n,&a,&b);
	 data1.a=a;
	 data1.b=b;
	 data1.n=n;
   	fd=open(FIFO_PATH,O_WRONLY);
   	write(fd,&data1,sizeof(data1));
   	close(fd);

   	fd=open(FIFO_PATH,O_RDONLY);
   	printf("read : %ld", read(fd,&c,sizeof(c)));
   	printf("result:%ld\n",c);
   	close(fd);
 	getchar();
 }
 return 0;
}

