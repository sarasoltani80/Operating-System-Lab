#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>

#define FIFO_PATH "q2.pipe"
struct data
{
 int a;
 int b;
 char n;
};


int main()
{
int a;
int b;
long int c;
char n;
int fd;

mkfifo(FIFO_PATH,0777);
while(1)

{

	struct data data1;
	fd=open(FIFO_PATH,O_RDONLY);
	read(fd,&data1,sizeof(data1));
	close(fd);
	a=data1.a;
	b=data1.b;
	n=data1.n;
	if(n=='p')
	{
		printf("power is doing %d %d\n", a, b);
           	c=1;
          	for(int i=0;i<b;i++)
           		c*=a;
           	printf("res = %d\n", c);		  
	}
	else if(n=='m')
	{
		printf("zarb is doing %d, %d\n", a, b);
         	c=a*b;
	}
   	fd=open(FIFO_PATH,O_WRONLY);
   	printf("count = %ld\n", write(fd,&c,sizeof(c)));
   	close(fd);
}
return 0;
}

