#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>

#define MAXCHILD 5
#define MAXIMUM 100
#define F_PATH "q1.pipe"

int fd[2];
void task(int id)
{
	close(fd[0]);
	while(1)
	{
	
	srand(time(NULL) + getpid());
	int r = rand() % 5 + 1;
	//printf("%d", r);
	sleep(r);
	printf("task %d has been done by child %d in %d seconds\n",id , getpid(), r);
	//fd = open(F_PATH, O_WRONLY);
	//printf("%d", r);
	write(fd[1], &r, sizeof(r));
	
	//exit(0);
	}
}


int main()
{

	//printf("1");
	int total = 0;
	int num=0;
	int x=pipe(fd); 
	//printf("%d",x);
	//mkfifo(F_PATH, 0777); //creat pipe
	
	 pid_t child[MAXCHILD];
	for(int i=0; i< MAXCHILD; i++)
	{
		child[i] = fork();
		//printf("%d\n", child[i]);
		if(child[i]==0) 
		{
			printf("in child %d \n", i);
			task(i);
			
		}
		
	}
	
	while(1)
	{
		close(fd[1]); 
		
		//fd = open(F_PATH, O_RDONLY);
		if(read(fd[0], &num, sizeof(int))>0)
		{
			//printf("2");
			total += num;
		}	
		//close(fd);
		
		
		
		//fd = open(F_PATH, O_WRONLY);
		//write(fd[0], &total, sizeof(total));
		
		if(total > MAXIMUM){
			printf("total equal to : %d\n", total);
			kill(0,SIGKILL);
		}
	}
}
