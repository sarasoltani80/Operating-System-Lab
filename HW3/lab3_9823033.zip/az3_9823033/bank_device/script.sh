touch Makefile
echo "obj-m = iutmodule.o
all:
	make -C /lib/modules/\$(shell uname -r)/build/ M=\$(PWD) modules
clean:
	make -C /lib/modules/\$(shell uname -r)/build M=\$(PWD) clean" > Makefile
make
sudo insmod iutmodule.ko
var=$(cat /proc/devices | grep bank_device)
arr=(${var// / })
sudo mknod -m 777 /dev/iutnode c ${arr[0]} 0
sudo gcc user2.c -o user2 -lpthread
./user2
sudo rm /dev/iutnode
sudo rmmod iutmodule
make clean
rm Makefile
sudo rm user2
