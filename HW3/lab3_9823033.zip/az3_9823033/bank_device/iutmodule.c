#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#define INIT_BALANCE 2000000
#define ACCOUNT_COUNT 100
#define DEVICE_NAME "bank_device"

//prototype of lateral functions
bool deposit(char*);
bool withdraw(char*);
bool transfer(char*);
int atoi(char*);
int int_len(int);
void decode_input(char*, int* );

MODULE_LICENSE("GPL");
MODULE_AUTHOR("sara");
MODULE_DESCRIPTION("OS AZ 3");
//MODULE_VERSION("0.1");

// FILE OPERATIONS
static int bank_open(struct inode*, struct file*);
static int bank_release(struct inode*, struct file*);
static ssize_t bank_read(struct file*, char*, size_t, loff_t*);
static ssize_t bank_write(struct file*, const char*, size_t, loff_t*);

static struct file_operations fops = {
   .open = bank_open,
   .read = bank_read,
   .release = bank_release,
   .write = bank_write,
};

static int major; // device major number. driver reacts to this major number.
int out[3]; //the output of decode_input function

struct bank {
	int acc[ACCOUNT_COUNT]; 	
};
static struct bank bal;

// Event LOAD
static int __init bank_init(void) {

    int i;
    for(i=0; i<ACCOUNT_COUNT; i++)
    	bal.acc[i] = INIT_BALANCE;

    major = register_chrdev(0, DEVICE_NAME, &fops); // 0: auto major ||| name is displayed in /proc/devices ||| fops.
    if (major < 0) {
        printk(KERN_ALERT "bank_device load failed.\n");
        return major;

    }
    printk(KERN_INFO "bank_device module loaded: %d\n", major);
    return 0;
}

// Event UNLOAD
static void __exit bank_exit(void) {
    unregister_chrdev(major, DEVICE_NAME);
    printk(KERN_INFO "bank_device module unloaded.\n");
}

// Event OPEN
static int bank_open(struct inode *inodep, struct file *filep) {
   printk(KERN_INFO "bank_device opened.\n");
   return 0;
}

// Event CLOSE
static int bank_release(struct inode *inodep, struct file *filep) {
   printk(KERN_INFO "bank_device closed.\n");
   return 0;
}

// Event READ
static ssize_t bank_read(struct file *filep, char *buffer, size_t len, loff_t *offset) {
    char message[1000];
    int i;
    int errors = 0;    
    message[0] = 0;
	printk(KERN_INFO "its in read.\n");
    for(i=0; i<ACCOUNT_COUNT; i++)
    	sprintf(message, "%s%d,", message, bal.acc[i]); //message + balance[i] stores in message
    
    errors = copy_to_user(buffer, message, strlen(message));
    return errors == 0 ? strlen(message) : -EFAULT;
}

// Event WRITE
static ssize_t bank_write(struct file *filep, const char *buffer, size_t len, loff_t *offset) {
    size_t maxdatalen = 17, ncopied;  
    char data[17];
    int datalen;

    //data = kmalloc(len+1 , GFP_KERNEL);

    if (len < maxdatalen) {
        maxdatalen = len;
    }

    ncopied = copy_from_user(data, buffer, maxdatalen);

    if (ncopied == 0) {
        printk("Copied %zd bytes from the user\n", maxdatalen);
    } else {
        printk("Could't copy %zd bytes from the user\n", ncopied);
    }

    data[maxdatalen] = 0;
    printk("Data from the user: %s\n", data);
    
    datalen = strlen(data);
    if(datalen == 0){
        printk(KERN_INFO "bank_device: writing format is wrong .\n");
        return 0;
    }
    
    else if(datalen == 1){
    	//int i;
    	
    	if(data[0] != 'r')
    	{
    	     printk(KERN_INFO "bank_device: writing format is wrong .\n");
    	     return 0;
    	}
    	
    	/*for(i=0; i<ACCOUNT_COUNT; i++)
    	    bal.acc[i] = INIT_BALANCE;
 
        printk(KERN_INFO "bank_device: all balances are reseted.\n");*/
    }
    
    else if( datalen >= 7 && datalen <= 17 ){
    printk(KERN_INFO "sara soltani.\n");
    	decode_input(data,out);
    		
    	if(data[0] == 't'){
    	printk(KERN_INFO "t is done.\n");
    	    if(transfer(data) == false)
    	    	return 0;
    	}
    	else if(data[0] == 'd'){
    	    if(deposit(data) == false)
    	        return 0;
    	}
    	else if(data[0] == 'w'){
    	    if(withdraw(data) == false)
    	    	return 0;
    	} 
    	else{
    	    printk(KERN_INFO "bank_device: writing format is wrong 5.\n");
    	    return 0;
    	}   
    }
    
    else{
    
    	printk(KERN_INFO "bank_device: writing format is wrong 4.\n");
    	return 0;
    }
    
    return len;
}


module_init(bank_init);
module_exit(bank_exit);

bool transfer(char* data){

    
    if(data[1] != ','){
    	printk(KERN_INFO "bank_device: writing format is wrong 7.\n");
    	return 0;
    }
    
    if(out[0] > 99 || out[1] > 99 || out[0] < 0 || out[1] < 0 ){
    	printk(KERN_INFO "bank_device: writing format is wrong 8.\n");
    	return 0;
    }

    
    if( out[0] < 10){
    
    	if(data[3] != ','){
    	    printk(KERN_INFO "bank_device: writing format is wrong 9.\n");
    	    return 0;
    	}
    		    
    	if( out[1] < 10){
    	    
    	    if(data[5] != ','){
    	        printk(KERN_INFO "bank_device: writing format is wrong 10.\n");
    	        return 0;
    	 	}
    	 }
    	 
    	else{
    	    if(data[6] != ','){
  	    	printk(KERN_INFO "bank_device: writing format is wrong 11.\n");
               return 0;
    	     }  	
    	}
    }
    else{
    	if(data[4] != ','){
    	    printk(KERN_INFO "bank_device: writing format is wrong 12.\n");
    	    return 0;
    	}
    	  
    	if(out[1] < 10){
    	
    	    if(data[6] != ','){
    	        printk(KERN_INFO "bank_device: writing format is wrong 13.\n");
    	        return 0;
    	    }
    	    
        }
    	else{
    	    if(data[7] != ','){
  	    	printk(KERN_INFO "bank_device: writing format is wrong 14.\n");
               return 0;
    	     }  
    	  	
    	}
    }
    
    if(out[2] <= 0){
    	printk(KERN_ALERT "output[2]: %d\n", out[2]);
    	
    	printk(KERN_INFO "bank_device: writing format is wrong 15.\n");
    	return 0;
    }
    	
    if(bal.acc[out[0]] < out[2]){
    	printk(KERN_INFO "bank_device: balance not enough 16.\n");
    	return 0;
    }  
     	
    bal.acc[out[0]] -= out[2];
    bal.acc[out[1]] += out[2];

    printk(KERN_INFO "bank_device: transfer is done.\n"); 
    	    
    return 1;
}

bool deposit(char* data){
   
    	
	if(data[1] != ',' || data[2] != '-' || data[3] != ','){
    	         printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	         return 0;
    	}

    	if( out[1] < 0 ){
    	    printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	    return 0;
    	}
    	    
    	if( out[1] < 10 ){
    	
    	    if(data[5] != ','){
    	        printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	        return 0;
    	    }
    	    
        }
    	else{
    	
    	    if(data[6] != ','){
  	    	printk(KERN_INFO "bank_device: writing format is wrong.\n");
               return 0;
    	     }  
    	     	
    	}
    	
    	if(out[2] <= 0){
    	    printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	    return 0;
    	}
    	    
    	bal.acc[out[1]] += out[2];
    	printk(KERN_INFO "bank_device: deposit is done.\n"); 
    	    
    	return 1;    
}

bool withdraw(char *data){

    if(data[1] != ','){
    	printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	return 0;
    }
    
    if( out[0] < 0 ){
    	printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	return 0;
    }
    
    if( out[0] < 10){
    	if(data[3] != ',' || data[4] != '-' || data[5] != ','){
    	    printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	    return 0;
    	}
    }
    else{
    	if(data[4] != ',' || data[5] != '-' || data[6] != ','){
    	    printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	    return 0;
    	}
    }
    
    if(out[2] <= 0){
    	printk(KERN_INFO "bank_device: writing format is wrong.\n");
    	return 0;
    }
    	
    if(bal.acc[out[0]] < out[2]){
    	printk(KERN_INFO "bank_device: balance not enough.\n");
    	return 0;
    }   	
    
    bal.acc[out[0]] -= out[2];
    printk(KERN_INFO "bank_device: withdraw is done.\n"); 

    return 1;      
}

int atoi(char* data){
	int sum, i;
	
	printk(KERN_ALERT "atoi working...\n");
	printk(KERN_ALERT "atoi input: %s\n", data);	
	
	sum = 0;
	for (i=0; data[i] >= '0' && data[i] <= '9' ; i++){
		sum *= 10;
		sum += (data[i] - '0');
	}
	printk(KERN_ALERT "atoi result: %d\n", sum);
	return sum;
}
int int_len(int data){
	int len = 0;
	if (!data) len++; // In case of data=0
	while(data){
		len++;
		data/=10;
	}
	return len;	
}
void decode_input(char* data, int* out){ // out: from, to, amount (-1 if '-')
	int temp;
	
	printk(KERN_ALERT "decode function input: %s\n", data);

	// from
	if (data[2] == '-') temp = -1;
	else temp = atoi(&(data[2]));
	printk(KERN_ALERT "temp barabar ast ba: %d\n", temp);
	out[0] = temp;
	
	printk(KERN_ALERT "out[0] set to %d and its len is %d.\n", out[0],int_len(out[0]));
	printk(KERN_ALERT "out[0] barabar ast ba: %d\n", out[0]);
	// to
	if (data[2+int_len(out[0])+1] == '-') temp = -1;
	else temp = atoi(&(data[2+int_len(out[0])+1]));
	out[1] = temp;
	printk(KERN_ALERT "out[1] set to %d and its len is %d.\n", out[1],int_len(out[1]));
	// amount
	temp = atoi(&(data[2+int_len(out[0])+1+int_len(out[1])+1]));
	out[2] = temp;
	printk(KERN_ALERT "out[2] set to %d and its len is %d.\n", out[2],int_len(out[2]));
	printk(KERN_ALERT "decoded input: %d,%d,%d\n", out[0],out[1],out[2]);
	
	printk(KERN_ALERT "decode function output: %s\n", data);
}
