#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

//printf("if you want to transfer or deposit or backdraw enter the command with comma without space");
int main(int argc , char * argv[])
{
	//printf("%d\n", argc);
	char * s;
	s = argv[1];	
	
	if(argc == 2 )
	{

		if(strcmp(s,"r")==0)
		{
			
			char readBuffer[1000]={0};
			int fd=open("/dev/project", O_RDONLY);
			read(fd,readBuffer, 1000);
			fprintf(stdout,"%s\n",readBuffer);
			close(fd);
			return 0;
		}
		else
		{
			char * Buffer;
			Buffer = argv[1];
			int fd=open("/dev/project", O_RDWR);
			write(fd,Buffer, strlen(Buffer));
			fprintf(stdout,"%s\n", Buffer);
			close(fd);
			
			/*printf("%d", argc);
			fprintf(stdout,"%s\n", "sara");
			fprintf(stdout,"%s\n", argv[0]);
			printf("sara");*/

			
		}
	}
	
	
}
