#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#define DEVICE_NAME "iut_device"
MODULE_LICENSE("GPL");
static int iut_open(struct inode*, struct file*);
static int iut_release(struct inode*, struct file*);
static ssize_t iut_read(struct file*, char*, size_t, loff_t*);
static ssize_t iut_write(struct file*, const char*, size_t, loff_t*);

static struct file_operations fops = {
   .open = iut_open,
   .read = iut_read,
   .write = iut_write,
   .release = iut_release,
};

static int major; // device major number. driver reacts to this major number.

static int __init iut_init(void) {
    major = register_chrdev(0, DEVICE_NAME, &fops); // 0: auto major ||| name is displayed in /proc/devices ||| fops.
    if (major < 0) {
        printk(KERN_ALERT "Device001 load failed!\n");
        return major;
    }
    printk(KERN_INFO "iut device module has been loaded: %d\n", major);
    return 0;
}

static void __exit iut_exit(void) {
    unregister_chrdev(major, DEVICE_NAME);
    printk(KERN_INFO " iut device module has been unloaded.\n");
}

static int iut_open(struct inode *inodep, struct file *filep) {
   printk(KERN_INFO " iut  device opened.\n");
   return 0;
}

static int iut_release(struct inode *inodep, struct file *filep) {
   printk(KERN_INFO "iut  device closed.\n");
   return 0;
}

static ssize_t iut_read(struct file *filep, char *buffer, size_t len, loff_t *offset) {
	int errors = 0;
	char *message = "IUT device example";
	errors = copy_to_user(buffer, message, strlen(message));
	return errors == 0 ? strlen(message) : -EFAULT;
}

static ssize_t iut_write(struct file *filep, const char *buffer, size_t len, loff_t *offset) {
        int errors = 0;
        char message[100];
        errors = copy_from_user(message, buffer, len);
	printk(KERN_INFO " iut  device has been writen.\n");
        return errors == 0 ? strlen(message) : -EFAULT;
}


module_init(iut_init);
module_exit(iut_exit);
