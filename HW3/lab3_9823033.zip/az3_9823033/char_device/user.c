#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
int main()
{
	char Buffer[] = "sara";
	int fd=open("/dev/c", O_RDWR);
	write(fd,Buffer, strlen(Buffer));
	fprintf(stdout,"%s\n", Buffer);
	close(fd);
	return 0;
}
