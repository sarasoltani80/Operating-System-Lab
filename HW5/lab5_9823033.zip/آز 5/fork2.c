#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>
#include <fcntl.h>

int main()
{
	while(1)
	{
	int status = 0;
	int alive = 0;
	pid_t child_id;
	struct timeval start,stop;                   
	srand(time(NULL));
	int r = rand() % 5 + 1;
	char buffer[100];
	sprintf(buffer,"%d", r);
	
	gettimeofday(&start,NULL);
	
	pid_t pid = fork();
	if(pid == 0)
	{
		child_id = execl("/home/acer/app.out", "app.out", buffer, NULL); 
		//printf("1");
	}

	alive = waitpid(pid,&status,0);

	
	if ( alive > 0)
	{
		
		gettimeofday(&stop,NULL);
		long sec=stop.tv_sec-start.tv_sec; 
		float m1=start.tv_usec; 
		float m2=stop.tv_usec;
		long elapsed = sec*1000+(m2-m1)/1000; 
		
		struct tm * temp;
		temp = localtime(&start.tv_sec);
		
		char buffer1[255];
		sprintf(buffer1, "%d-%d-%d \t %d:%02d" , temp->tm_year + 1900 , temp->tm_mon, temp->tm_mday, temp->tm_hour, temp->tm_min);
		
		printf("%s \t %ld \t %d\n",buffer1,elapsed,r);
		
	}
	}
}
