#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>
#include <fcntl.h>
#define MAXCHILD 5
void task(int id)
{
	srand(time(NULL) + getpid());
	int r = rand() % 5 + 1;
	sleep(r);
	printf("task %d has been done by child %d in %d seconds\n",id , getpid(), r);
	exit(0);
}
int main()
{
	pid_t child [MAXCHILD]; 
	for(int i=0; i< MAXCHILD; i++)
	{
		child[i] = fork();
		if(child[i] == 0)
		{
			task(getpid());
		}
	}

	while (wait(NULL) > 0 )
		printf("all the children have been died\n");

}
