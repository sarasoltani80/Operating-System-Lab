#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>
#include <fcntl.h>

#define MAXCHILD 5
void task(int id)
{
	srand(time(NULL) + getpid());
	int r = rand() % 5 + 1;
	sleep(r);
	printf("task %d has been done by child %d in %d seconds\n",id , getpid(), r);
	exit(0);
}
int main()
{
	int status = 0;
	int alive = 0;
	pid_t child [MAXCHILD]; 
	for(int i=0; i< MAXCHILD; i++)
	{
		child[i] = fork();
		if(child[i] == 0)
		{
			task(i);
		}
	}

	while(1)
	{
		sleep(5);
		
		for(int i=0; i< MAXCHILD; i++)
		{
			alive = waitpid(child[i],&status,WNOHANG);
			if(alive > 0)
			{
				child[i] = fork();
				task(i);
			}
		}
	}

}
