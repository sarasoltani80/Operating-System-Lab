#include <stdio.h> 
#include <string.h> 
#include <pthread.h> 
#include <semaphore.h> 
#include <unistd.h> 
#define THREADS 4 
#define size 7
sem_t sem1;
int total = 0;

int array1[size]={1,2,3,4,5,6,7};
int array2[size]= {7,5,0,1,2,1,0};


void *routine1(void * n ) {
	 
	int m=(int)n;
	int product = 0;
	printf("in %d\n", m);
	for(int index=m;index < size; index +=THREADS)
		product += array1[index] * array2[index];
	
	sem_wait(&sem1);  
	total += product;
	printf("product is %d\n" , product);       
	sem_post(&sem1);      
	pthread_exit(NULL); 
}

int main()
{
	sem_init(&sem1,0,1);  
	pthread_t threads[THREADS];
	 //int thread_id[THREADS];
	 
	 for ( int i=0;i<THREADS;i++) {        
	 	pthread_create(&threads[i],NULL,routine1,(void *)i); 
	 }
 
 
 	for (int i=0; i<THREADS; i++)  
 	        pthread_join(threads[i],NULL); 
 	        
 	printf("total is %d\n" , total);
 }
	 
	
	
