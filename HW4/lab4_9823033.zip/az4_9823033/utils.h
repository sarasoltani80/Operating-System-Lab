enum {
   command1      = _IO('A', 1),
   command2
};

