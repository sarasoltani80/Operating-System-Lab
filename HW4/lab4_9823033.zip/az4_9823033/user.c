#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include "utils.h"

int main() {
    int fd, ret;

 char* data_from_kernel= (char*)malloc(100);
 const char* data = "data is from user";
 
    //memset(iut_data1, 0, sizeof(struct iut_data));
    //iut_data1->arg1 = 10;

    fd = open("/dev/iut_device2", O_RDWR);
    if (fd < 0) {
        perror("open");
        exit(0);
    }
    ret = ioctl(fd, command1 , data);
    if (ret < 0) {
        perror("ioctl");
        exit(0);
    }
    
    
    printf("hi");
    ret = ioctl(fd, command2 , data_from_kernel );
    printf("%s", data_from_kernel);
    if (ret < 0) {
        perror("ioctl");
        exit(0);
    } 
    
    close(fd);
    return 0;
}
