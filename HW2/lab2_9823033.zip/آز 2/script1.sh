#!/bin/bash
if [ -d $1 ];then
	echo dir is exist
else

	mkdir $1
fi
cd $1
for ((c=$3;c<=$4;c++));
do
	touch "$2-$c.txt"
	chmod 744 "$2-$c.txt"
	echo file has created
done

