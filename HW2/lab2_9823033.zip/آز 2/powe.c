#include "powe.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int power (int a , int b )
{
	int result = 1;
	for (int i=0; i<b ; i++)
	{
		result *= a;
	}
	return result;
}
