#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>

struct mytasks{
	char name[100];
	int pid;
};


int main(void) {
	int c = 0 ;
	struct mytasks obj[100];
	while (1){

		long ret = syscall(550, &obj);
		for(int i=0; i< ret; i++)
		{
			//printf("%d", i);
			printf("name is %s and pid is %d\n", obj[i].name , obj[i].pid);
		}
		fflush(stdout);
		sleep(10);
		c+=1;
	}
	return 0;
}
