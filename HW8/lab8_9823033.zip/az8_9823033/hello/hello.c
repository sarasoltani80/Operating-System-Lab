#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/sched.h>

SYSCALL_DEFINE1(hello, int, number)
{
printk("Hello From Kernel\n");
return number*number;
}
SYSCALL_DEFINE2(hello2, int, number, int, number2)
{
printk("Hello From Kernel2\n");
return number*number2;
}
SYSCALL_DEFINE1(hello3, struct mytasks * , obj)
{
	int counter=0;
	struct task_struct *task;
	for_each_process(task){
		strncpy(obj[counter].name , task->comm, 99);
		obj[counter].pid = task->pid;
		counter++;
		if(counter >= 99)
			break;
	}
	return counter;
		
}
